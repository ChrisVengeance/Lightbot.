List = {
	"Articuno": 2000,
	"Celebi": 4000,
	"Entei": 5000,
	"Groudon": 8000,
	"Ho-oh": 10000,
	"Kyogre": 8000,
	"Lugia": 8000,
	"UnCloned_Mew": 0,
	"Cloned_Mew": 6000,
	"Mewtwo": 8000,
	"Moltres": 4000,
	"Raikou": 5000,
	"Rayquaza": 10000,
	"Suicune": 6000,
	"Zapdos": 3000
}

List['UnCloned_Mew'] = List['Mewtwo'] * 2 + List["Cloned_Mew"]
Sum  = 0
for x in List:
	print("{0} = Reward('{0}',[],{1})".format(x, round(List[x],2)))
	Sum += List[x]

print("Average Legend Price is {}".format(round(Sum/len(List),2)))