import challonge
import LimitlessChallonge
import Player
import PlayerDataBase

LmC = LimitlessChallonge.LimitlessChallonge()

playerName = input('What is your Player Name? ')

LmC.playerData(playerName)



### Put things in Player Objects
### print from there