import challonge
import datetime
import Player
import PlayerDataBase

challonge.set_credentials("Wertfuzzy77", "ygvSkq7WEE4i0CYguyyWGUAqOLSs5klPcDA2ZXcY")
MAX_NAME_LENGTH = 15
CURRENT_TOURNAMENT_LIST = []
MONTHS = ["January", "February", "March", "April", "May", "June", 'July', "August", "September", "October", "November", "December"]
URL_LIST = ["LimitlessMCTournament","Level100Battle","7kg6eqbc","gqsmr131","k4ssiskw","20jkjerl","1juwze7i","4h5lg5li","vhfqet4z","cske41s2","mlhxhd4c"]

class LimitlessChallonge():

	def __init__(self):
		challonge.set_credentials("Wertfuzzy77", "ygvSkq7WEE4i0CYguyyWGUAqOLSs5klPcDA2ZXcY")
		for url in URL_LIST:
			CURRENT_TOURNAMENT_LIST.append(self.LimitlessTourney(url))

	# Retrives a Tournament based off an input String
	def Tourney(self, input = "LimitlessMCTournament"):
		return challonge.tournaments.show(input)

	# Retrives a Limitless Tournament based off an input String
	def LimitlessTourney(self, input = "Level100Battle"):
		return challonge.tournaments.show("LimitlessMC-{}".format(input))

	# Returns the Month as a String, given a numerical month
	def monthToString(self, num):
		return MONTHS[num-1]


	# Everything After This Point should take a Tournament Object

	# Prints The Details of a Tournament. (Name, Date, ID, and Type)
	def printTourneyDetails(self, Tournament):
		T = Tournament
		part = challonge.participants.index(T["id"])

		#Title
		print(T["name"])
		#Tourney Data
		if(self.hasHappened(T)):
			print("Date: Completed\t\t\tParticipants: {}".format(len(part)))
		else:
			print("Date: {} {},{}\t\tParticipants: {}".format(self.monthToString(T["start-at"].month), T["start-at"].day, T["start-at"].year, len(part)))

		print("Type: {}\tID: {}".format(T["tournament-type"], T["id"]))

	def TourneyDetails(self, Tournaments = CURRENT_TOURNAMENT_LIST):
		result = ""
		for T in Tournaments:
			part = challonge.participants.index(T["id"])

			#Tourney Data
			if not self.hasHappened(T):
				result += T["name"] + "\n"
				result += "Date: {} {},{}\t\tParticipants: {}".format(self.monthToString(T["start-at"].month), T["start-at"].day, T["start-at"].year, len(part)) + "\n"
				result += "Type: {}\tID: {}".format(T["tournament-type"], T["id"]) + "\n"
				result += "URL: https://limitlessmc.challonge.com/{}".format(T["url"]) +"\n"
				result += "\n"
		return result

	# Prints Information for a singular Tournament, Includes Tournament Data and Participant Ranking
	def printTourneyInfo(self, Tournament):
		T = Tournament
		part = challonge.participants.index(T["id"])

		self.printTourneyDetails(T)

		#Participants
		print("Current Standings:")
		print("Name of Player\tRank\tID")
		for P in part:
			name = str(P["username"])
			rank = P["final-rank"]
			ID = P["id"]

			# Format the Names to be Nice, all the Same length
			if(name == None):
				name = str(P["name"])
			if(len(name) > MAX_NAME_LENGTH): 
				name = name[:MAX_NAME_LENGTH]
			while(len(name) < MAX_NAME_LENGTH):
				name = name + " "

			print("{} {}\t{}".format(name, rank if rank!=None else 'No Rank', ID))

	#Prints Multiple Tournament's information
	def printTourneysInfo(self, tournaments=CURRENT_TOURNAMENT_LIST):
		for T in tournaments:
			self.printTourneyInfo(T)
			print()

	# Returns if a Tournament Has Happened yet, given a Tournament Object. A Tournament Today will be Counted as Happened
	def hasHappened(self, tournament):
		currentTime = datetime.datetime.now()
		if(currentTime.year < tournament["start-at"].year): # Checks Year
			return False # In the Next Years
		elif(currentTime.year > tournament["start-at"].year):
			return True # In Previous Years
		elif(currentTime.year == tournament["start-at"].year): # Same Year
			if(currentTime.month < tournament["start-at"].month):# Checks Month
				return False # In the Next Years
			elif(currentTime.month > tournament["start-at"].month):
				return True # In the Previous Years
			elif(currentTime.month == tournament["start-at"].month): # Same Month
				if(currentTime.day < tournament["start-at"].day): # Checks Day
					return False # In the Next Days
				elif(currentTime.day >= tournament["start-at"].day):
					return True # In Previous Days, or Today

	# Prints ths Matches of a Tournament, Given the Tournament Object
	def printMatches(self, tournament):
		Matches = challonge.matches.index(tournament["id"])
		#self.printTourneyDetails(tournament)
		print("Match History")
		for M in Matches:
			if(M["winner-id"] != None):
				WinName = self.findUserName(tournament,M["winner-id"])
				LoseName = self.findUserName(tournament,M["loser-id"])
				print("{}\t{}\t{}-{}".format(WinName if WinName!=None else M["winner-id"], LoseName if LoseName!=None else M["loser-id"],M["scores-csv"][0],M["scores-csv"][2]))

	def printAllMatches(self):
		for T in CURRENT_TOURNAMENT_LIST:
			self.printTourneyDetails(self.LimitlessTourney(T))
			self.printMatches(self.LimitlessTourney(T))

	def findUserName(self, tournament, ID):
		participants = challonge.participants.index(tournament["id"])
		for p in participants:
			if(p["id"] == ID):
				if(p["name"] != None):
					return p["name"]
				else:
					return p["username"]

	def findUserID(self, name, tournament):
		participants = challonge.participants.index(tournament["id"])
		for p in participants:
			#print("Does {}/{} = {}?".format(p["name"],p["username"], name))
			if(p["name"] == name):
				#print("Yes, Found ID")
				return p["id"]
			elif(p["username"] == name):
				#print("Yes, Found ID")
				return p["id"]					
		return "NOTFOUND"

	def playerData(self, name, tournaments = CURRENT_TOURNAMENT_LIST):
		for T in tournaments:
			ID = self.findUserID(name, T)
			if ID != "NOTFOUND" and self.hasHappened(T) == True:
	
				print("{}\tDate: {} {},{}".format(T["name"],self.monthToString(T["start-at"].month), T["start-at"].day, T["start-at"].year))

				part = challonge.participants.show(T["id"], ID)

				if(part["final-rank"] == None):
					print("Was Registered, Did not check in")
				else:
					print("Rank: {}".format(part["final-rank"]))
				Matches = challonge.matches.index(T["id"])
				self.printPlayerMatches(Matches, part)
				print("")

	def playerRank(self, player, tournament):
		if(player == None):
			return None
		ID = self.findUserID(player, tournament)
		url = "LimitlessMC-" + tournament["url"]
		for p in challonge.participants.index(url):
			if p["name"] == player:
				return p["final-rank"]
			elif p["username"] == player:
				return p["final-rank"]
		return None

	def exportPlayerTournaments(self, player, tournaments = CURRENT_TOURNAMENT_LIST):
		name = player.Name
		for T in tournaments:
			rank = self.playerRank(name, T)
			#print("{}, {}, {}".format(name, T["url"], rank))
			if(rank != None):
				player.addTournament(T["url"], rank, T["participants-count"])


	def exportPlayerMatches(self, playerDataBaseObject, tournaments = CURRENT_TOURNAMENT_LIST):
		for T in tournaments:
			print("=========={}==========".format(T["name"]))
			Matches = challonge.matches.index(T["id"])
			for M in Matches:
				Winner = playerDataBaseObject.findPlayer(self.findUserName(T,M["winner-id"]))
				Loser = playerDataBaseObject.findPlayer(self.findUserName(T,M["loser-id"]))
				if(Winner != None and Loser != None):
					print("{} beat {}".format(Winner.Name, Loser.Name))
					Winner.addWin(Loser)
					Loser.addLoss(Winner)
				# elif(Winner == None and Loser != None):
				# 	print("Winner is None")
				# elif(Winner != None and Loser == None):
				# 	print("Loser is None")
				# elif(Winner == None and Loser == None):
				# 	print("Both are None")


	def getNames(self, tournaments = CURRENT_TOURNAMENT_LIST):
		List = []
		for T in tournaments:
			#print(T["name"])
			part = challonge.participants.index("LimitlessMC-" + T["url"])
			for P in part:
				if P["name"] not in List and P["name"] != None:
					List.append(P["name"])
				elif P["username"] not in List:
					List.append(P["username"])
		return List

	def printPlayerMatches(self, Matches, player):
		for M in Matches:
			if(M["winner-id"] == player["id"]):
				print("{} Won against {}".format(player["username"], self.findUserName(self.Tourney(M["tournament-id"]),M["loser-id"])))
			elif(M["loser-id"] == player["id"]):
				print("{} Lost against {}".format(player["username"], self.findUserName(self.Tourney(M["tournament-id"]),M["winner-id"])))

 
	# def writeTournament(self, file = open("Output",'w'), tournament]):
	# 	T = tournament
	# 	part = challonge.participants.index(T["id"])

	# 	self.writeTourneyDetails(file,T)

	# 	#Participants
	# 	file.write("Current Standings:")
	# 	file.write("Name of Player\tRank")
	# 	for P in part:
	# 		name = str(P["username"])
	# 		rank = P["final-rank"]

	# 		# Format the Names to be Nice, all the Same length
	# 		if(name == None):
	# 			name = str(P["name"])
	# 		if(len(name) > MAX_NAME_LENGTH): 
	# 			name = name[:MAX_NAME_LENGTH]
	# 		while(len(name) < MAX_NAME_LENGTH):
	# 			name = name + " "

	# 		file.write("{} {}".format(name, rank if rank!=None else 'Unranked'))

	# def writeTourneyDetails(self, file = open("Output",'w'), tournament]):
	# 	T = tournament
	# 	part = challonge.participants.index(T["id"])
	# 	#Title
	# 	file.write(T["name"])

	# 	#Tourney Data
	# 	file.write("Type: {}\tID: {}".format(T["tournament-type"], T["id"]))
	# 	if(self.hasHappened(T)):
	# 		file.write("Date: Completed\t\tParticipants: {}".format(len(part)))
	# 	else:
	# 		file.write("Date: {} {},{}\t\tParticipants: {}".format(self.monthToString(T["start-at"].month), T["start-at"].day, T["start-at"].year, len(part)))