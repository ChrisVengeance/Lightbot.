import challonge
import Player
import PlayerDataBase
import LimitlessChallonge
import time


def main(LmC, DB):
	start_time = time.time()
	Names = []

	print("===========Names===========")
	Names = LmC.getNames()
	DB.addPlayers(Names)
	print("===========Done_Names===========")

	print("===========Matches===========")
	LmC.exportPlayerMatches(DB)
	f = open("./Tournament./" + "AddinMatches.txt", 'r')
	while f.readline() == "Match:\n":
		winner = DB.findPlayer(f.readline())
		loser = DB.findPlayer(f.readline())
		if winner != None and loser != None:
			print("Adding Addin Match: {} beat {}".format(winner, loser))
			winner.addWin(loser)
			loser.addLoss(winner)
		else:
			print("Invalid Addin Match: {} beat {}".format(winner, loser))
	print("===========Done_Matches===========")

	print("===========Players===========")
	for player in DB.Players:
		print("Working on {}".format(player.Name))
		LmC.exportPlayerTournaments(player)
	print("===========Done_Players===========")

	print("===========Rankings===========")
	List = DB.Rankings()
	f = open("./OutputFolder./" + "Ranking" +'.txt', 'w')
	Rank = 1
	for output in List:
		f.write("Name: {}, Rank: {}, Index: {}\n".format(output.Name, str(Rank), str(round(output.FuzzyIndex,1))))
		output.Rank = Rank
		Rank+=1
	print("===========Done_Ranking===========")

	print("===========Writing_To_Files===========")
	for player in DB.Players:
		f = open("./OutputFolder./" + player.Name+'.txt', 'w')
		f.write(str(player))
	print("===========Done_Writing===========")

	f = open("./OutputFolder./" + "Tournaments.txt",'w')
	f.write(LmC.TourneyDetails())
	print("My program took seconds {} to run".format(time.time() - start_time))

if __name__ == '__main__':
	LmC = LimitlessChallonge.LimitlessChallonge()
	DB = PlayerDataBase.PlayerDataBase()
	main(LmC, DB)
