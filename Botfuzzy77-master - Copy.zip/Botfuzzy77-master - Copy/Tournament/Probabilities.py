import time
WEIGHTS = {
  '0': 0.150,
  '1': 0.509,
  '2': 3.000,
  '3': 3.308,
  '4': 7.722,
  '5': 18.853
}
desired = 0
STEP = 0
PERSEC = 861787

def isGood(values):
  localMaxs = 0
  localMins = 0
  for i in range(0, len(values) - 1, 1):
    if i == 0 and values[0] > values[1]:
      localMaxs += 1
    elif i == 5 and values[5] > values[4]:
      localMaxs += 1
    else:
      if values[i] >= values[i+1] and values[i] >= values[i-1]:
        localMaxs += 1
      if values[i] <= values[i+1] and values[i] <= values[i-1]:
        localMins += 1
  return localMaxs == 1 and localMins == 0
def Max(str):
  return min(
    int(100*desired/WEIGHTS[str] * STEP/100) + 1,
    STEP - 1)

def Min(str):
  return -min(
    -int(STEP - (Max('0')+Max('1')+Max('2')+Max('3')+Max('4')+Max('5')-Max(str))),
    int(0))

def calculate(tolerance, step, **kwargs):
  global STEP
  global desired
  Debug = kwargs.get('Debug', False)
  desired = kwargs.get('desired', 2)
  skip = kwargs.get('skip', 1)
  STEP = step
  print("Desired: ${}".format(desired*1000))
  MAX0 = Max('0')
  MAX1 = Max('1')
  MAX2 = Max('2')
  MAX3 = Max('3')
  MAX4 = Max('4')
  MAX5 = Max('5')

  MIN0 = Min("0")
  MIN1 = Min("1")
  MIN2 = Min('2')
  MIN3 = Min('3')
  MIN4 = Min("4")
  MIN5 = Min('5')
  if Debug:
    print("{}-{}% {}-{}% {}-{}% {}-{}% {}-{}% {}-{}%".format(int(100*MIN0/step), int(100*MAX0/step),int(100*MIN1/step), int(100*MAX1/step), int(100*MIN2/step), int(100*MAX2/step), int(100*MIN3/step), int(100*MAX3/step), int(100*MIN4/step), int(100*MAX4/step), int(100*MIN5/step), int(100*MAX5/step)))
  MAXcycles = 100*((MAX0-MIN0) * (MAX1-MIN1) * (MAX2-MIN2) * (MAX3-MIN3) * (MAX4-MIN4))/step
  cycles = 0
  if Debug:
    print("Steps: {}".format (step))
  if Debug:
    print("MAXCycles: {}".format(format(int(MAXcycles), ',d')))
  if Debug:
    print("MAX time: {}s".format(round(MAXcycles/PERSEC, 3)))
  for e in range(MIN0,MAX0,skip):
    if(100*e/step % 1 == 0) and Debug:
      print(100*e/step)
    if(e + MAX1 + MAX2 + MAX3 + MAX4 + MAX5 < 100):
      continue
    if(e*100/STEP*WEIGHTS['0'] + MAX1*100/STEP*WEIGHTS["1"]+MAX2*100/STEP*WEIGHTS["2"] + MAX3*100/STEP*WEIGHTS["3"] + MAX4*100/STEP*WEIGHTS["4"] + MAX5*100/STEP*WEIGHTS["5"] < desired):
      continue

    for i in range(MIN1,MAX1,skip):
      if((e*WEIGHTS['0'] + i*WEIGHTS['1'])/step >= desired):
        continue
      if(e + i + MAX2 + MAX3 + MAX4 + MAX5 < 100):
        continue
      if(e*100/STEP*WEIGHTS['0'] + i*100/STEP*WEIGHTS["1"]+MAX2*100/STEP*WEIGHTS["2"] + MAX3*100/STEP*WEIGHTS["3"] + MAX4*100/STEP*WEIGHTS["4"] + MAX5*100/STEP*WEIGHTS["5"] < desired):
        continue

      for j in range(MIN2,MAX2,skip):
        if((e*WEIGHTS['0'] +i*WEIGHTS['1'] + j*WEIGHTS['2'])/step >= desired):
          continue
        if(e + i + j + MAX3 + MAX4 + MAX5 < 100):
          continue
        if(e*100/STEP*WEIGHTS['0'] + i*100/STEP*WEIGHTS["1"]+j*100/STEP*WEIGHTS["2"] + MAX3*100/STEP*WEIGHTS["3"] + MAX4*100/STEP*WEIGHTS["4"] + MAX5*100/STEP*WEIGHTS["5"] < desired):
          continue

        for k in range(MIN3,MAX3,skip):
          if((e*WEIGHTS['0'] +i*WEIGHTS['1'] + j*WEIGHTS['2'] +k*WEIGHTS["3"])/step >= desired):
            continue
          if(e + i + j + k + MAX4 + MAX5 < 100):
            continue
          if(e*100/STEP*WEIGHTS['0'] + i*100/STEP*WEIGHTS["1"]+j*100/STEP*WEIGHTS["2"] + k*100/STEP*WEIGHTS["3"] + MAX4*100/STEP*WEIGHTS["4"] + MAX5*100/STEP*WEIGHTS["5"] < desired):
            continue

          for n in range(MIN4,MAX4,skip):
            if((e*WEIGHTS['0'] +i*WEIGHTS['1'] + j*WEIGHTS['2'] +k*WEIGHTS["3"] + n*WEIGHTS['4'])/step >= desired):
              continue
            if(e + i + j + k + n + MAX5 < 100):
              continue
            if(e*100/STEP*WEIGHTS['0'] + i*100/STEP*WEIGHTS["1"]+j*100/STEP*WEIGHTS["2"] + k*100/STEP*WEIGHTS["3"] + n*100/STEP*WEIGHTS["4"] + MAX5*100/STEP*WEIGHTS["5"] < desired):
              continue

            if 100-100*(e+i+j+k+n)/STEP < MIN5 or 100-100*(e+i+j+k+n)/STEP > MAX5:
              continue

            m = 100-100*(e+i+j+k+n)/STEP
            cycles += 1
            # if(cycles % 1000000 == 0):
            #   print(cycles/1000000," Million")

            if(e <= 0)or(i <= 0)or(j <= 0)or(k <= 0)or(n<=0)or(m<=0):
              continue

            res = WEIGHTS['0'] * e/step + \
                  WEIGHTS['1'] * i/step + \
                  WEIGHTS['2'] * j/step + \
                  WEIGHTS['3'] * k/step + \
                  WEIGHTS['4'] * n/step + \
                  WEIGHTS['5'] * m/step - \
                  .001
            if round(res, tolerance) == desired:
              if(isGood([100*e/step, 100*i/step, 100*j/step, 100*k/step, 100*n/step, 100*m/step])):
                print("[{},{},{},{},{},{}] = {}".format(100*e/step, 100*i/step, 100*j/step, 100*k/step, 100*n/step, 100*m/step, res))

  if Debug:
    print("Cycles: {}".format(format(int(cycles), ',d')))
  if Debug:
    print("EST time: {}s".format(round(cycles/PERSEC, 3)))
  if Debug:
    print("Efficiency: {}".format(round(100 - 100*cycles/MAXcycles, 5)))



def Half():
  print("HALF")
  start = time.clock()
  calculate(2, 200, desired = .5)
  runtime = time.clock() - start
  print("runtime: {}s".format(round(runtime, 5)))
  print()

def One():
  print("ONE")
  start = time.clock()
  calculate(4, 100, desired = 1)
  runtime = time.clock() - start
  print("runtime: {}s".format(round(runtime, 5)))
  print()

def Two():
  print("TWO")
  start = time.clock()
  calculate(4, 100, desired = 2)
  runtime = time.clock() - start
  print("runtime: {}s".format(round(runtime, 5)))
  print()

def Five():
  print("FIVE")
  start = time.clock()
  calculate(4, 100, desired = 5)
  runtime = time.clock() - start
  print("runtime: {}s".format(round(runtime, 5)))
  print()

def Ten():
  print("TEN")
  start = time.clock()
  calculate(1, 100, desired = 10, skip = 2)
  runtime = time.clock() - start
  print("runtime: {}s".format(round(runtime, 5)))
  print()

if __name__ == "__main__":
  # start = time.clock()
  # calculate(4, 200, desired = 2)
  # runtime = time.clock() - start
  # print("runtime: {}s".format(round(runtime, 5)))
  # Half()
  # One()
  # Two() 
  Five()
  Ten()
