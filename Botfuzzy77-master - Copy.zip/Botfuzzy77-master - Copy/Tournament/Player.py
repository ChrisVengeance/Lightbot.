import challonge
import LimitlessChallonge

class Player:
	def __init__(self, name):
		self.Name = name
		self.Tournaments = []
		self.PlayersBeat = []
		self.PlayersLost = []
		self.PB = []
		self.PL = []
		self.Rank = None
		self.FuzzyIndex = 100

	def addTournament(self, URL, Rank, Participants):
		self.Tournaments.append({"TournamentURL":URL, "Rank":Rank, "Participants":Participants})

	def addLoss(self, player):
		if(player not in self.PL):
			self.PlayersLost.append({"Player":player,"Count":1})
			self.PL.append(player)
		else:
			for tup in self.PlayersLost:
				if tup["Player"] == player:
					tup["Count"] = tup["Count"] + 1
		self.FuzzyIndex -= ((self.FuzzyIndex/player.FuzzyIndex) * (10))

	def addWin(self, player):
		if(player not in self.PB):
			self.PlayersBeat.append({"Player":player,"Count":1})
			self.PB.append(player)
		else:
			for tup in self.PlayersBeat:
				if tup["Player"] == player:
					tup["Count"] = tup["Count"] + 1
		self.FuzzyIndex += ((player.FuzzyIndex/self.FuzzyIndex) * (10))

	def compare(self, player):
		return self.FuzzyIndex - player.FuzzyIndex

	def __str__(self):
		Statement = ""
		Statement +="Name: {}".format(self.Name) + "\n"
		Statement +="FuzzyIndex: {}, Rank: {}\n".format(round(self.FuzzyIndex,1), str(self.Rank))
		try:
			Statement +="Win-Lose Ratio: {}".format(str(len(self.PlayersBeat)/len(self.PlayersLost)))
		except Exception:
			Statement += "Win-Lose Ratio: {}".format("Infinite")
		Statement += "\n"
		Statement += "Tournaments Participated in {}".format(len(self.Tournaments)) + "\n"
		for T in self.Tournaments:
			Statement += "TournamentURL: http://limitlessmc.challonge.com/LimitlessMC-" + str(T["TournamentURL"]) + "\nRank: " + str(T["Rank"]) + " Out of " + str(T["Participants"]) + " Participants\n\n"
		Statement += "\n"
		Statement +="Players Won Against\n"
		for P in self.PlayersBeat:
			Statement += P["Player"].Name + ": " + str(P["Count"]) + "\n"
		Statement += "\n\n"
		Statement +="Players Lost Against\n"
		for P in self.PlayersLost:
			Statement += P["Player"].Name + ": " + str(P["Count"]) + "\n"
		return Statement

