import Player

class PlayerDataBase:
	def __init__(self):
		self.Players = []

	def addPlayer(self, name):
		P = Player.Player(name)
		P.Name = name
		self.Players.append(P)

	def addPlayers(self, names):
		for name in names:
			self.addPlayer(name)

	def findPlayer(self, name):
		for player in self.Players:
			if player.Name == name:
				return player
		return None

	def comparePlayers(self, player1, player2):
		Wins = 0
		Losses = 0
		for play in player1.PlayersBeat:
			if(player2.Name == play.Name):
				Wins = Wins + 1
		for play in player2.PlayersBeat:
			if(player1.Name == play.Name):
				Losses = Losses + 1
		print("Matches between {} and {}".format(player1.Name, player2.Name))
		print("Wins: {}\tLosses: {}".format(Wins, Losses))

	def Rankings(self):
		filtered = [x for x in self.Players if x.FuzzyIndex != 100]
		return sorted(filtered, key=lambda x: round(x.FuzzyIndex,1), reverse=True)
