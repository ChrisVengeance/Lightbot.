import challonge
import LimitlessChallonge

LmC = LimitlessChallonge.LimitlessChallonge()

LmC.printTourneysInfo()