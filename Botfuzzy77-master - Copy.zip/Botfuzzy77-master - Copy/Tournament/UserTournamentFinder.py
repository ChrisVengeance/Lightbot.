import challonge
import LimitlessChallonge

LmC = LimitlessChallonge.LimitlessChallonge()

url = input('Please Input the Url of Tournament to Get Info of (Include the Organization in front if needed, Ex LimitlessMC-20jkjerl for the April Fools Tournament: ')
print("Tournament Info")
LmC.printTourneyInfo(LmC.Tourney(url)) ## Prints Tournament Details and Ranking
LmC.printMatches(LmC.Tourney(url)) ## Prints Match Ups