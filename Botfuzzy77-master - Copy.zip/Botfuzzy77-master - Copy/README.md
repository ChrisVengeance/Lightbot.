# Limitless_Challonge
Challonge Python Scripts for the Limitless MC Server


# Basic User Things
There are two Python Scripts that will diplay data for Tournaments/Players Respectfully
The Player Script Takes in a player Name, While the Tournament one takes in a url.
For Limitless Tournaments Make sure you add the "LimitlessMC-" infront of the url otherwise it will not find it. 

More Scripts to come About Player Relations and Overall Ranking

