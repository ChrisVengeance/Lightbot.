import discord
from discord.ext import commands
import random
import traceback
import asyncio
import random
import time
import math
import http.client
import urllib.parse
import datetime
import json
import os
from collections import defaultdict

from Tournament.tournament import *
from cleverbot import Cleverbot

import Logger

from Util.pokemonEV import *
from Util.Question import *
from Util.FileExporter import *
from Util.cmds import *
from Util.Types import *
from Util.EVs import EV
from Util.Pokemonlist import *
from Util.FilePrinter import *
from Util.pokemonEV import *

from mcstatus import MinecraftServer


Link_to_legends = "http://imgur.com/a/MHNM2"
Legends =["Articuno", "Celebi", "Entei", "Groudon", "Ho-oh", "Kyogre", "Lugia", "Mew", "Mewtwo", "Moltres", "Raikou", "Rayquaza", "Suicune", "Zapdos"]
Colors = {"Orange":"xl", "Green":"Apache", }

VERSION = "0.14.2.6"
description = '''A Bot for the GranPulse/LimitlessMC Server Discord! Version {}
(Created by Lightning/WertFuzzy77)'''.format(VERSION)
bot = commands.Bot(command_prefix='.', description=description)

CLEVERBOT = Cleverbot()

voice = None
player = None

startTime = time.time()
afks = {}
inTrivia = False

def isStaff(ctx):
    for role in ctx.message.author.roles:
        if role.name == "Staff":
            return True
    return False

messageNum = 0
EXTENTIONS = ['Util.StaffCmds', 'Util.FlavorTexts', 'Music.Music']

CONFIG = {}
with open('CONFIG.json', 'r') as f:
    CONFIG = json.load(f)

DATATAGS = ["Online", "Welcome"]

@bot.event
async def on_ready():
    #Log = open("./Logs./" +Fev "log" + str(time.time()) + ".txt",'w')
    print('Logged in as')
    print(bot.user.name)
    print(bot.user.id)
    print('------')

    for extension in EXTENTIONS:
        try:
            bot.load_extension(extension)
        except Exception as e:
            print('Failed to load extension {}\n{}: {}'.format(extension, type(e).__name__, e))

    await bot.change_presence(game=discord.Game(name='with Your Soul'))
    await bot.loop.create_task(changeIcons())

async def changeIcons():
    await bot.wait_until_ready()
    while not bot.is_closed:
        fp = open("Icons/" + random.choice(os.listdir("Icons")), 'rb')
        NewAvatar = fp.read()
        await bot.edit_profile(avatar = NewAvatar)
        await asyncio.sleep(600)

@bot.command()
async def feedback():
    'Returns a link to a Google Forums, where you can leave feedback for the bot'
    await bot.say("**Use This Link to Give Feedback on me :D**																																		\nhttp://goo.gl/forms/5o0YV1wbmXAhv6XT2")

@bot.command()
async def status():
    'Returns the Status of the Bot, along with Additional Information'
    await bot.say("UpTime: {}s".format(str(datetime.timedelta(seconds = round(time.time() - startTime,1)))))
    await bot.say("Total Messages: {}".format(messageNum))
    await bot.say("Servers Joined: {}".format(len(bot.servers)))

@bot.command(pass_context = True)
async def server(ctx, IP = "mc.limitlessmc.net"):
    'Returns Information on the Limitless MC server!'
    try:
        server = MinecraftServer.lookup(IP)
        status = server.status()
        await bot.say("**Server IP**: {}".format(IP))
        await bot.say("**Server Status**\n *Online Players*: {} players out of {}\n *Ping*: {} ms\n *MC Version*: {}".format(status.players.online, status.players.max, status.latency, status.version.name))
        await bot.say("**Players Online**:\n *{}...*".format(", ".join([x.name for x in status.players.sample])))
    except Exception as e:
        await bot.say("*Server is Down :(*")

async def readConfig():
    with open('CONFIG.json', 'r') as f:
        CONFIG = json.load(f)

async def writeConfig():
    with open('CONFIG.json', 'w') as f:
        json.dump(CONFIG, f)

@bot.group(pass_context = True)
async def config(ctx):
    'Allows you to change settings for the server'
    if ctx.invoked_subcommand is None:
        await bot.say('Invalid config command passed...')

@config.command(pass_context = True)
async def Set(ctx, dataTag:str, value : bool):
    'Allows you to set config values'
    await readConfig()
    try:
        CONFIG[ctx.message.server.name]
    except Exception:
        CONFIG[ctx.message.server.name] = {}
    if dataTag not in DATATAGS:
        await bot.say("Only available config settings are: {}".format(", ".join(DATATAGS)))
    CONFIG[ctx.message.server.name][dataTag] = value
    await writeConfig()
    await bot.say("Sucessfully Set {} to {}".format(dataTag, value))

@config.command(pass_context = True)
async def Get(ctx, dataTag:str):
    'Allows you to get config values'
    await readConfig()
    try:
        CONFIG[ctx.message.server.name]
    except Exception:
        CONFIG[ctx.message.server.name] = {}
    try:
        value = CONFIG[ctx.message.server.name][dataTag]
    except Exception:
        await bot.say("Only available config settings are: {}".format(", ".join(list(CONFIG[ctx.message.server.name].keys()))))
    await bot.say("**{}** is set to **{}**".format(dataTag, value))

@config.command(pass_context = True)
async def All(ctx):
    'Gives you all of the Settings for this server'
    await readConfig()
    try:
        CONFIG[ctx.message.server.name]
    except Exception:
        CONFIG[ctx.message.server.name] = {}
    server = CONFIG[ctx.message.server.name]
    await bot.say(
"""Server Settings are as Follows:
Welcome new members: **{}**
Send a message when a player comes online: **{}**""".format(server["Welcome"], server["Online"]))

@bot.command()
async def source():
    'Returns a link to the source code for this bot'
    await bot.say("https://github.com/77Wertfuzzy77/Botfuzzy77")

@bot.command()
async def invite():
    'Returns a Link to the Invite URL for this bot'
    await bot.say("https://discordapp.com/oauth2/authorize?client_id=187608834381053952&scope=bot&permissions=00000008")
    
@bot.event
async def on_member_update(before, after):
    return
    message = None
    #print(CONFIG[before.server.name]["Online"])
    if CONFIG[before.server.name]["Online"] is "False":
        print("Disabled Member Join on {}".format(before.server.name))
        return
    try:
        if before.server.name in ["The Pleb Privateers"] or before.server.id in ["126122560596213760"]:
            return
        if str(before.status) == "offline" or str(before.status) == "idle" and str(after.status) == "online":
            message = await bot.send_message(before.server, "**{}**({}) is now Online!".format(before.name, before.top_role if before.top_role.name != "@everyone" else "No Role"))
            await asyncio.sleep(20)
            await bot.delete_message(message)
        if str(before.status) == "online" and str(after.status) == "offline":
            message = await bot.send_message(before.server, "**{}**({}) is now Offline!".format(before.name, before.top_role if before.top_role.name != "@everyone" else "No Role"))
            await asyncio.sleep(5)
            await bot.delete_message(message)
    except Exception as e:
        print(type(e).__name__, e)

    
@bot.event
async def on_message(message):
    #Logging
    global messageNum
    try:
        Logger.LOG.write("{1} : {0.server}, {0.channel}, {0.author}, {0.clean_content}\n".format(message, time.strftime("%d %b %Y %H:%M:%S", time.gmtime())))
    except Exception as e:
        print("Someting wong\n", type(e).__name__, e)

    # Dont DO anything if message author is Bot
    if(message.author.id == bot.user.id):
        return

    for member in message.mentions:
        #print(member.name, afks)
        if member in afks:
            await bot.send_message(message.channel, "{} is afk for reason:\n**{}**".format(member.name, afks[member]))

    messageNum += 1

    #print(message.content + "\n" + message.content.upper())
    if(len(message.content) > 10 and message.content.upper() == message.content and message.content.isalpha()):
        await bot.delete_message(message)
        #print("removing caps message")
        return

    # if Parsable as Limitless URL
    if("http://limitlessmc.net/f/viewtopic.php?" in message.content):
        await bot.send_message(message.channel, ForumPost(message.content))

    # Easter Egg, returns "wut" if Bot is mentioned
    Ids = [x.id for x in message.mentions]
    if("255237593887670272" in Ids):
        #print(message.content.replace("<@!255237593887670272>", ""))
        response = CLEVERBOT.ask(message.content.replace("<@!255237593887670272>", ""))
        await bot.send_message(message.channel, response)
        return

    if(message.content == "Wut" or message.content == "wut"):
        await bot.send_message(message.channel, "Hek")
        return
        

    # if(message.content == "Bet" or message.content == "bet"):
    #     await bot.send_message(message.channel, "bet")
    #     return
    # Normal IF Statement
    # if(message.channel.id != '148202028244402176' or message.author.name == "Lightning"):
    #     #print("{0.author}, {0.content}".format(message))
    try:
        await bot.process_commands(message)
    except Exception as e:
        return

@bot.command(pass_context=True, hidden=True)
async def debug(ctx, *, code : str):
    IDs = ["134441036905840640", "226028320104382464"]
    if(ctx.message.author.id not in IDs):
        return
    """Evaluates code."""																														
    code = code.strip('` ')
    python = '```py\n{}\n```'
    result = None

    try:
        result = eval(code)
    except Exception as e:
        await bot.say(python.format(type(e).__name__ + ': ' + str(e)))
        return

    if asyncio.iscoroutine(result):
        result = await result

    await bot.say(python.format(result))

@bot.command()
async def joined(member : discord.Member):
    """Says when a member joined."""
    raw_date = member.joined_at

    await bot.say('{0.name} joined in {1}'.format(member, ))

@bot.command(hidden = True)
async def clever(*playerInput : str):
    'Talks to the Bot via Cleverbot API'
    #response = CLEVERBOT.ask(" ".join(playerInput))
    await bot.say("This CMD is Obsolete, please just Mention me in a message and I will respond :D")
    

@bot.command()
async def ev(*playerInput : str):
    """Returns Best Pokemon to Find Certain EVs 
    Inputs are 'HP', 'SPD', 'DEF', 'SP.DEF', 'ATT', 'SP.ATT'
    Or you can do !ev [pokemon] to get the EV drops for a certain pokemon"""
    List = ["HP", "SPD", "DEF", "SP.DEF", "ATT", "SP.ATT"]
    pkm = []
    if(playerInput[0].upper() in List):
        try:
            print("EV:'{}'".format(playerInput[0].upper()))
            result = EV[playerInput[0].upper()]
            #print("Result: {}".format(result))
        except Exception:
            traceback.print_exc()
            await bot.say('Not a Valid input')
            await bot.say('You Typed {} which is not one of the inputs'.format(playerInput[0].upper()))
            return
    else:
        for name in playerInput:
            print("Searching for {}".format(name))
            pkm.append(name)

        try:
            result = "**``{}``**".format(find(pkm))
        except Exception:
            traceback.print_exc()
            await bot.say('Not a Valid input')
            return

    await bot.say(result)

@bot.command()
async def pokemon(pkmn = "charizard"):
    '''Returns Links to Pokemon pages'''
    await bot.say("Pixelmon Page: http://pixelmonmod.com/wiki/index.php?title={}".format(pkmn))
    await bot.say("Bulbapedia Page: http://bulbapedia.bulbagarden.net/wiki/{}".format(pkmn))
    await bot.say("Pokemon DB: http://pokemondb.net/pokedex/{}".format(pkmn))
    await bot.say("Smogon: http://www.smogon.com/dex/bw/pokemon/{}".format(pkmn))

@bot.command()
async def fml():
    '''Returns a Random Post from fmylife.com'''
    await bot.say("*{}*".format(fmlText()))

@bot.command(pass_context = True)
async def afk(ctx, * reason : str):
    '''Sets you as AFK, and the Bot will auto Reply for you with the Given Reason. (Put no Reason to Un-Afk)'''
    if(len(reason) == 0):
        del afks[ctx.message.author]
        await bot.say('''{} is no Longer AFK'''.format(ctx.message.author.name))
    else:
        addAfk(ctx.message.author, ' '.join(reason))
        await bot.say('''{} is now AFK for reason:\n**{}**'''.format(ctx.message.author.name, ' '.join(reason)))

def addAfk(user, message):
    try:
        afks[user] = message
        return 1
    except Exception as e:
        return 0

@bot.command()
async def conch(question : str):
    'Ask the Magic Conch a Question'
    conn = http.client.HTTPSConnection("8ball.delegator.com")
    question = urllib.parse.quote(question)
    conn.request('GET', '/magic/JSON/' + question)
    response = conn.getresponse()
     
    if response.status == http.client.OK:
        lines = response.read().decode(encoding='UTF-8').split('\n')
        await bot.say("*" + lines[3][15:-2] + "*")
        await bot.say("The Conch has Spoken!")
     
    conn.close()


@bot.command(pass_context = True, hidden = True)
async def trivia(ctx, num = 10):
    '''Trivia Plugin!
Please use ";ans [YourAnswer]" to answer a question.
Ex. ";ans Pikachu"'''

    #if isStaff(ctx) ==  False:
        #return
    inTrivia = True
    trivia_timeout = 30
    current_channel = ctx.message.channel.id
    winners = defaultdict(int)

    async def ask(final_answer:list):
      """ Condensed methodology for asking questions in any question mode """
      await bot.say("""You have Thirty seconds to submit an answer using ;ans [Your Answer]...
        \n\n**Note:** If you know it and want to save it for the end, be wary that it may not recognize some answers if multiple are simultaneous!
        """)
      final_answer_f = list(map(lambda x: x.lower().replace(" ", ""), final_answer))
      print(final_answer_f)

      answers = {}
      timeout = time.time() + (trivia_timeout - 15)
      while time.time() < timeout:
        ans = await bot.wait_for_message(timeout=1.0)
        if ans and ans.channel.id == current_channel and ans.author.id != '167123959031005186' and ans.content.startswith(";ans"):
            answers[ans.author.name] = ans.content.replace(";ans ", "")
            try:
                await bot.delete_message(ans)
            except Exception:
                traceback.print_exc()
                continue



      await bot.say('Currently received an answer from: {}\n\nYou have ten more seconds to respond.'.format(', '.join(answers)))

      timeout = time.time() + 15
      while time.time() < timeout:
        ans = await bot.wait_for_message(timeout=1.0)
        if ans and ans.channel.id == current_channel and ans.author.id != '167123959031005186' and ans.content.startswith(";ans"):
            answers[ans.author.name] = ans.content.replace(";ans ", "")
            try:
                await bot.delete_message(ans)
            except Exception:
                traceback.print_exc()
                continue


      final_message = "**Here are the results**:\n"
      for name,resp in answers.items():
        final_message += "{} guessed `{}` ... ".format(name, resp)
        if resp.lower().replace(" ", "") in final_answer_f:
          winners[name] += 1
          final_message += "**CORRECT!**\n"
        else:
          final_message += "*Incorrect*\n"

      final_message += '\nThe answer was: **{}**\n'.format(final_answer)
      await bot.say(final_message + '\n')


    GameType = random.choice(["Text", "HiddenAbility", "Question", "Mixed"])
    GameType = "Mixed"
    await bot.say("Lets play the {} game".format(GameType))
    for i in range(1, num + 1 if num>=1 else 11):
        await bot.say("Next Question in 5 Seconds")
        timeout = time.time() + 5
        while time.time() < timeout:
            ans = await bot.wait_for_message(timeout=1.0)

        pokemon = random.choice(Pokemonlist)
        await bot.say("Question {}".format(i))
        if GameType == "Mixed":
            my_list = ["Text"] * 1 + ["HiddenAbility"] * 2 + ["Question"] * 3
            choose = random.choice(my_list)
        else:
            choose = GameType

        if(choose == "Question"):
            QA = random.choice(Questions)
            Q = QA[0]
            A = QA[1:]
            await bot.say('**{}**'.format(Q))
            await ask(A)
        if(choose == "HiddenAbility"):
            ability = hiddenAbility(pokemon)
            await bot.say("What is the Hidden Ability of **{}**".format(pokemon))
            await ask([ability])
        elif(choose == "Text"):
            text = TextEntry(pokemon)																		
            await bot.say("Which Pokemon is This?\n**{}**".format(text))
            await ask([pokemon])

    winners_message = "**Current winners:**\n"
    for q in sorted(winners, key=winners.get, reverse=True):
        winners_message += '{}: *{}* correct\n'.format(q, winners[q])
    await bot.say(winners_message + '\n')
    inTrivia = False											




if __name__ == '__main__':
    bot.run('MjU1MjM3NTkzODg3NjcwMjcy.CyasOQ.4VdCyFCUPO5BVNGAhydMIoX9Rp8')
