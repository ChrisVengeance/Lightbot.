import time

LOG = open("./Logs./" + "log" + str(time.time()) + ".txt",'w')
