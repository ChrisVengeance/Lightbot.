import glob

def isSynced(IGName):
	files = glob.glob("Sync/*.txt")
	for f in files:
		filetext = open(f, 'r').read()
		#print("{} and {}".format(filetext, IGName))
		if filetext == IGName:
			return True
	return False