def findPokemonEVs(f, name):
    line = f.readline()
    while(line.find("EOF") == -1):
        if(line.lower().find(name.lower()) != -1):
            return line
        line = f.readline()
    return "Pokemon Not Found\n"

def find(names):
    Stats = ["HP", "ATT", "DEF", "SP.ATT", "SP.DEF", "SPEED"]
    f = open("./Util./" +"PokemonFile.txt", 'r')
    firstline = f.readline()
    result = "WARNING: NOT 100 PERCENT ACCURATE\n"
    for name in names:
        raw_line = findPokemonEVs(f,name)
        tabCount = 0
        count = 1
        print(raw_line)
        if raw_line != None:
            for c in raw_line:
                if c == '\t' and tabCount >= 1 and tabCount < 7:
                    print("Start of Values", printPerChar(raw_line[count+1:len(raw_line)]))
                    #result += " " + Stats[tabCount-2] + ": "
                    thingy = printPerChar(raw_line[count+1:len(raw_line)])
                    result += " HP:{} ATT:{} DEF:{} SP.ATT:{} SP.DEF:{} SPD:{}\n".format(thingy[0], thingy[1],thingy[2],thingy[3],thingy[4],thingy[5])
                    print(count,Stats[tabCount-2],": ")
                    tabCount += 10
                    break;
                elif c == '\t':
                    tabCount += 1
                    result += c + ""
                    print("Found Tab")
                else:
                    count += 1 
                    result += c
                    print(count,c)
        f = open("./Util./" +"PokemonFile.txt", 'r')
    return result

def printPerChar(toPrint):
    final = ""
    for c in toPrint:
        if(c == '\t'):
            final += "0"
        elif(c == '\n'):
            final += "N"
        elif(c == " "):
            final += ""
        else:
            final += c
    return final
