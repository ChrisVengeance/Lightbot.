EV = {'HP':
"""Pokemon that Give Health EVs
Caterpie - 1
Nidoran (female) - 1
Nidorina - 2
Clefairy - 2
Jigglypuff - 2
Slowpoke - 1
Grimer - 1
Lickitung - 2
Chansey - 2
Kangaskhan - 2
Lapras - 2
Ditto - 1
Snorlax - 2
Chinchou - 1
Lanturn - 2
""",
'SPD':
"""Pokemon that Give Speed EVs
Weedle - 1
Pidgey - 1
Pidgeotto - 2
Rattata - 1
Raticate - 2
Spearow - 1
Fearow - 2
Pichu - 1
Pikachu - 2
Raichu - 3
Vulpix - 1
Zubat - 1
Golbat - 2
Diglett - 1
Dugtrio - 2
Meowth - 1
Persian - 2
Poliwag - 1
Poliwhirl - 2
Ponyta - 1
Rapidash - 2
Voltorb - 1
Electrode - 2
Staryu - 1
Starmie - 2
Electabuzz - 2
Magikarp - 1 (finally, a use.)
Elekid - 1
""",
'DEF':
"""Pokemon that Give Defence EVs
Metapod - 2
Kakuna - 2
Sandshrew - 1
Sandslash - 2
Geodude - 1
Graveler - 2
Slowbro - 2
Shellder - 1
Onix - 1
Exeggcute - 1
Cubone - 1
Marowak - 2
Koffing - 1
Weezing - 2
Rhyhorn - 1
Tangela - 1
Miltank - 2
Aron - 1
Lairon - 2
""",
'SP.DEF':
"""Pokemon that Give Special Defence EVs
Venonat - 1
Tentacool - 1
Tentacruel - 2
Seel - 1
Dewgong - 2
Drowzee - 1
Hypno - 2
Hitmonchan - 2
Mr. Mime - 2
Eevee - 1
""",
'ATT':
"""Pokemon that Give Attack EVs
Ekans - 1
Arbok - 2
Nidoran (male) - 1
Nidorino - 2
Paras - 1
Mankey - 1
Primeape - 2
Growlithe - 1
Machop - 1
Machoke - 2
Bellsprout - 1
Weepinbell - 2
Krabby - 1
Kingler - 2
Hitmonlee - 2
Rhydon - 2
Goldeen - 1
Seaking - 2
""",
'SP.ATT':
"""Pokemon that Give Special Attack EVs
Oddish - 1
Gloom - 2
Psyduck - 1
Golduck - 2
Abra - 1
Kadabra - 2
Magnemite - 1
Magneton - 2
Gastly - 1
Haunter - 2
Horsea - 1
Jynx - 2
Magmar - 2
Mareep - 1
Flaaffy - 2
Girafarig - 2
Numel - 1
Lunatone - 2

Also, SP.ATTs are given by Boss Towers, which makes this one of the easiest EVs to train for
"""
}