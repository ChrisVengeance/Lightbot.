import json
import requests


#r = requests.get("http://pokeapi.co/api/v2/pokemon/pikachu")
#Json = r.json()["stats"]
#print(json.dumps(Json, indent=4, sort_keys=True))

def getEVs(name:str):
	name = name.lower()
	r = requests.get("http://pokeapi.co/api/v2/pokemon/"+name)
	Json = r.json()["stats"]
	toRet = []
	for X in range(0, 6, 1):
		toRet.append(Json[X]["stat"]["name"] + " " + str(Json[X]["effort"]))
	return "\n".join(toRet)