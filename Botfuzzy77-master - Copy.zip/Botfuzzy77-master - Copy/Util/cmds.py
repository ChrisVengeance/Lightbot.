Commands = {
	"Bonemeal":"""
```/brush sphere 70%31:1,10%38:0,5%37:0,5%38:8,10%air 3
/mask >2```
	"""
	,
	"Pathway":"""
```/brush sphere stone:6 2
/mask 2,dirt,sand```
	"""
}