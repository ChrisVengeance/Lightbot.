import discord
import random
from discord.ext import commands
from apiclient.discovery import build
import asyncio

class FlavorTexts:
	def __init__(self, bot):
		self.bot = bot

	@commands.command(hidden = True)
	async def hep(self):
	    await self.bot.say("Dont Be Lazy, Type .help")

	@commands.command(hidden = True)
	async def srbr(self):
	    await self.bot.say("Dont Be Lazy, Type .server")

	@commands.command()
	async def rps(self, player_input = None):
		"Allows the player to play Rock, Paper, Scissors with the Bot. Simply enter, R, P or S to play!"
		if player_input == None or player_input not in ['R', 'P', 'S']:
			await self.bot.say("You need to put in either (R)ock, (P)aper, or (S)cissors")
			return
		Values = {"R":":right_facing_fist:", "P":":raised_back_of_hand:", "S":":v:"}
		bot_choice = random.choice(["R", "P", "S"])
		await self.bot.say("You throw {}\nI throw {}".format(Values[player_input], Values[bot_choice]))
		if(bot_choice == player_input):
			await self.bot.say("Its a Tie, we both put {}".format(Values[player_input]))
		if bot_choice == "R":
			if player_input == "P":
				await self.bot.say("**You Win!**")
			if player_input == "S":
				await self.bot.say("I Win! :stuck_out_tongue:")
		if bot_choice == "P":
			if player_input == "S":
				await self.bot.say("**You Win!**")
			if player_input == "R":
				await self.bot.say("I Win! :stuck_out_tongue:")
		if bot_choice == "S":
			if player_input == "R":
				await self.bot.say("**You Win!**")	
			if player_input == "P":
				await self.bot.say("I Win! :stuck_out_tongue:")

	@commands.command(pass_context = True)
	async def rate(self, ctx):
	    "Rates the Player"
	    if ctx.message.author.id == '226028320104382464':
	    	await self.bot.say("{} Is Actually God".format(ctx.message.author.name))
	    	return
	    await self.bot.say("{} Is Kinda Cool".format(ctx.message.author.name))

	@commands.command(Hidden = True)
	async def kys(self):
	    await self.bot.say(random.choice([
	    	"Hey Mean!",
	    	"How about... no",
	    	"Sure, just gimme some bleach",
	    	"Im Sorry, That goes against my programming"]))

	@commands.command(hidden = True)
	async def kms(self):
	    await self.bot.say(random.choice([
	    	"Nu, I be sad then ;-;",
	    	"Don't Die",
	    	"Bet",
	    	"Do it, you wont",
	    	"Good :)"]))


	@commands.command(pass_context = True)
	async def image(self, ctx, *toGoogle : str):
		if(ctx.message.channel.id == "232595777069776897"):
			return
		"Returns the First Found Image on Google Images for this Input"
		service = build("customsearch", "v1", developerKey="AIzaSyB-ILulo61cnlt68SUP6giJwmyI3S6JgbQ")

		googleSearch = " ".join(toGoogle)
		res = service.cse().list(
		    q=googleSearch,
		    cx='001619551424816794764:dqn9nzjp57a',
		    searchType='image',
		    num=1,
		    fileType='jpg',
		    safe= 'off'
		).execute()

		if not 'items' in res:
		    await self.bot.say('ERROR')
		else:
		    for item in res['items']:
		        await self.bot.say(item['link'])

	@commands.command(pass_context = True)
	async def punch(self,ctx, member : str):
	    'Adds Emotion'
	    await self.bot.say(":punch: *{} Punched {}* :punch:".format(ctx.message.author.name, member))

	@commands.command(pass_context = True)
	async def cuddle(self,ctx, member : str):
	    'Adds Emotion'
	    await self.bot.say(":hugging: *{} Cuddled {}* :hugging:".format(ctx.message.author.name, member))

	@commands.command()
	async def lmgtfy(self, * toGoogle : str):
		'Returns a Link to a "Let me Google That For You" Page'
		await self.bot.say("http://lmgtfy.com/?q={}".format("+".join(toGoogle)))

	@commands.command()
	async def funify(self, * text : str):
		'Funifies a given text input'
		finalOutput = ""
		for x in text:
			for character in x:
				for i in range(0,int(random.random() * 2 + 1),1):
					finalOutput += random.choice([character.lower()] * 10 + [character.upper()] * 10 + [character.lower() + random.choice("1234567890-=[];',./!@#$%^&(_+{}: ")] + [character.upper() + random.choice("1234567890-=[];',./!@#$%^&(_+{}: ")])
			finalOutput += " "
		await self.bot.say(finalOutput)

	@commands.command()
	async def choose(self, * options : str):
		'Chooses from a set of things'
		await self.bot.say(random.choice(["Hmm, tough choice", "Oh, Thats easy", "Alright, picked one"]))
		await self.bot.say("Chosen Option: " + random.choice(options))

	@commands.command(pass_context = True)
	async def luck(self,ctx):
		'Returns the Player\'s Luck'
		luck = round(random.random() * 100,2)
		if 0 <= luck <= 20:
			text = "Completly Horrible"
		elif 20 <= luck <= 40:
			text = "Pretty Bad"
		elif 40 <= luck <= 60:
			text = "Not Bad"
		elif 60 <= luck <= 80:
			text = "Pretty Good"
		elif 80 <= luck <= 100:
			text = "HAXX"
		else:
			text = "CHEATER"

		await self.bot.say("{0.message.author.name}'s luck is {1} out of 100, which is **{2}**".format(ctx,luck,text))

	@commands.command(pass_context = True)
	async def kill(self,ctx, member : str):
	    'Adds Emotion'
	    await self.bot.say(":skull: *{} Killed {}* :gun:".format(ctx.message.author.name, member))

	@commands.command(pass_context = True)
	async def Holiday(self,ctx, member : str):
	    'Adds Emotion'
	    await self.bot.say(":christmas_tree: *{} Wishes You A Merry Xmas {}* :christmas_tree:".format(ctx.message.author.name, member))

	@commands.command(hidden = True)
	async def boss(self, old, correct):
		new = []
		cur = 0
		for c in old:
			if correct[cur] == '0':
				new.append(self.inc(c))
			else:
				new.append(c)
			cur += 1
		await self.bot.say("".join(new))

	def inc(self, c):
		values = {"A":"D", "D":"S", "S":"B", "B":"E", "E":"F", "F":"A"}
		return values[c]

def setup(bot):
	bot.add_cog(FlavorTexts(bot))