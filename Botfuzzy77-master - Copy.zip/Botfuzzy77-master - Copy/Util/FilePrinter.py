from bs4 import BeautifulSoup
import requests
from Util.IDS import *
import random
import re

def nickName(name):
	#print("http://bulbapedia.bulbagarden.net/wiki/" + name)
	r = requests.get("http://bulbapedia.bulbagarden.net/wiki/" + name)
	soup = BeautifulSoup(r.text, "html.parser")
	val = soup.select("span")
	try:
		return (val[6].text)
	except Exception:
		print("ERROR")

def hiddenAbility(name):
	#print("http://bulbapedia.bulbagarden.net/wiki/" + name)
	r = requests.get("http://bulbapedia.bulbagarden.net/wiki/" + name)
	soup = BeautifulSoup(r.text, "html.parser")
	val = soup.select("tr")
	HA = val[23].select("Hidden")
	string = val[23].text.strip()

	string = string.replace("\n", "|||||||||||")
	#print(string)
	index = string.find("Hidden Ability")
	#print(index)
	clean = string[index-20:index].replace("|", "")
	if(clean == "  "):
		clean = "No Ability"
	#print(clean)
	return("{}".format(clean))

def ID(name):
	return IDS.PokemonIDs[name]

def TextEntry(name):
	r = requests.get("http://bulbapedia.bulbagarden.net/wiki/" + name)
	soup = BeautifulSoup(r.text, "html.parser")
	val = soup.select("p")
	choice = random.choice([2,3])
	return (val[choice].text.replace(name, "[Pokemon]")[:300])

def Status():
	r = requests.get("http://limitlessmc.net/")
	soup = BeautifulSoup(r.text, "html.parser")
	val = soup.select("#serverstatus")
	return val[0].text

def ForumPost(url : str, num = 0):
	r = requests.get(url)
	soup = BeautifulSoup(r.text, "html.parser")
	Side = soup.select("div.pull-left")
	val = soup.select("div.content")

	#mainclean = val[0].text

	text = str(val[num]).split('<br/>')
	text[num] = text[num].replace('<div class="content">', '')
	text[len(text)-1] = text[len(text)-1].replace('</div>', '')
	nText = []
	for l in text:
		nText.append(cleanLine(l))
	mainclean = '\n'.join(nText)


	clean = "**" + Side[2].text.replace("\n", '') + "**" + Side[3].text.replace('\t', '') + "------------------------------------" + "\n" + mainclean
	if(len(clean) > 1500):
		clean = clean[:1450] + "...\n------------------------------------\n*If you would like to read more, click the link below!*\n{}".format(url)


	#print(clean)
	return clean

def fmlText():
	r = requests.get("http://www.fmylife.com/random")
	soup = BeautifulSoup(r.text, "html.parser")
	val = soup.select("p.content")
	if(len(val) < 1):
		print("ERROR in FML cmd")
		r = requests.get("http://www.fmylife.com/random")
		soup = BeautifulSoup(r.text, "html.parser")
		val = soup.select("p.content")
	return val[0].text

def cleanLine(line):
	print('cleaning')
	#print(line)
	if('<span style="font-weight: bold">' in line):
		line = line.replace('<span style="font-weight: bold">', '**')
		line = line.replace('</span>', '**')
		line.replace("\n", '')
		#line = "**" + line + "**\n"
	line = line.replace('<img alt=";)" src="./images/smilies/icon_e_wink.gif" title="Wink"/>', ';)')
	line = line.replace('<img alt=":(" src="./images/smilies/icon_e_sad.gif" title="Sad"/>', ':(')



	if('<a class="postlink" href="' in line):
		line = line.replace('<a class="postlink" href="', '')
		line = line.replace('</a>', '')
	#print(line)
	return line

def youtube(input1:str, num = 0):
	r = requests.get("https://www.youtube.com/results?search_query="+input1)
	soup = BeautifulSoup(r.text, "html.parser")
	val = soup.select("h3")
	m = re.search('href="/watch\?v=(.{11})"', str(val[4 + num]))
	#print(str(val[4 + num]), '\n')
	#print(m.group(0)[15:-1])
	if(m == None):
		return youtube(input1, num+1)
	return 'https://www.youtube.com/watch?v=' + m.group(0)[15:-1]



# r = requests.get("https://www.youtube.com/results?search_query=diglett")
# soup = BeautifulSoup(r.text, "html.parser")
# val = soup.select("h3")
# #print(val)
# print(val[4])
# m = re.search('href="/watch\?v=(.{11})"', str(val[4]))
# print(m.group(0)[15:-1])

# count = 0
# for v in val:
# 	if count < 50:
# 		try:
# 			print(str(count), v)
# 		except Exception as e:
# 			print(e, "Error")
# 	count += 1


# print(val.text)
# while val[num].text == "Cacophony":
# 	num =+ 1
# 	try:
# 		print(val[num].text)
# 	except Exception:
# 		print("ERROR")

# f = open(val[23].text.strip(), 'r')
# print(f.read())




########### Getting Pictures #########################
# r = requests.get("http://pokemondb.net/pokedex/national")
# soup = BeautifulSoup(r.text, "html.parser")
# val = soup.select(".infocard-tall")



# name = "Venusaur"

# #print(val[ID(name) - 1]['class'])
# val2 = val[ID(name) - 1].select("a")
# count = 0
# print(val2[0]["data-sprite"])