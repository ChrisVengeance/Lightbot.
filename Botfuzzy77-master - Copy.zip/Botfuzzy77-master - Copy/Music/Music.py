import discord
from discord.ext import commands
import asyncio
import random
import datetime
import json
from Util.FilePrinter import youtube


MIN_VIEWS = 10000
MAX_PERCENT_DISLIKE = 0.25
MAX_SONGS_SHOWN = 10

class MusicPlayer:

	def isStaff(self, ctx):
	    for role in ctx.message.author.roles:
	        if role.name == "Staff":
	            return True
	    return False
	playList = None
	playList = {
	"ACDC" : ["https://www.youtube.com/watch?v=v2AC41dglnM", "https://www.youtube.com/watch?v=gEPmA3USJdI", "https://www.youtube.com/watch?v=pAgnJDJN4VA", "https://www.youtube.com/watch?v=etAIpkdhU9Q", "https://www.youtube.com/watch?v=LdRxXID_b28"],
	"Sheeran":["https://www.youtube.com/watch?v=lp-EO5I60KA","https://www.youtube.com/watch?v=FOjdXSrtUxA","https://www.youtube.com/watch?v=nSDgHBxUbVQ", "https://www.youtube.com/watch?v=c4BLVznuWnU", "https://www.youtube.com/watch?v=2fngvQS_PmQ", "https://www.youtube.com/watch?v=UAWcs5H-qgQ"],
	"WEEB" : ["https://www.youtube.com/watch?v=kuNixp-wvWM"],
	"Adele" : ["https://www.youtube.com/watch?v=Ri7-vnrJD3k", "https://www.youtube.com/watch?v=rYEDA3JcQqw", "https://www.youtube.com/watch?v=hLQl3WQQoQ0", "https://www.youtube.com/watch?v=DeumyOzKqgI", "https://www.youtube.com/watch?v=dx7sLNyIeQk"],
	"Maroon" : ["https://www.youtube.com/watch?v=09R8_2nJtjg", "https://www.youtube.com/watch?v=iEPTlhBmwRg", "https://www.youtube.com/watch?v=qpgTC9MDx1o", "https://www.youtube.com/watch?v=NmugSMBh_iI", "https://www.youtube.com/watch?v=KRaWnd3LJfs"],
	"Coldplay" : ["https://www.youtube.com/watch?v=QtXby3twMmI", "https://www.youtube.com/watch?v=VPRjCeoBqrI", "https://www.youtube.com/watch?v=fyMhvkC3A84", "https://www.youtube.com/watch?v=dvgZkm1xWPE", "https://www.youtube.com/watch?v=k4V3Mo61fJM"],
	"2Cellos" : ["https://www.youtube.com/watch?v=uT3SBzmDxGk", "https://www.youtube.com/watch?v=N-YuSKeFMxY", "https://www.youtube.com/watch?v=qfGggAGITwg", "https://www.youtube.com/watch?v=Mx0xCI1jaUM", "https://www.youtube.com/watch?v=-FcmuOW1qt8"],
	"Old" : ["https://www.youtube.com/watch?v=lHje9w7Ev4U", "https://www.youtube.com/watch?v=Soa3gO7tL-c", "https://www.youtube.com/watch?v=Ee_uujKuJMI", "https://www.youtube.com/watch?v=uAsV5-Hv-7U", "https://www.youtube.com/watch?v=-Du-CWASm20", "https://www.youtube.com/watch?v=RaG8faaFUMM", "https://www.youtube.com/watch?v=TG8Ect3Xn7w", "https://www.youtube.com/watch?v=feeHTm-dYGg", "https://www.youtube.com/watch?v=T3phscjgc_A"]
	}
	def __init__(self, bot):
		with open('Playlists.json', 'r') as f:
			self.playList = json.load(f)
		self.bot = bot
		self.voice = None
		self.player = None
		self.queue = []
		self.bot.loop.create_task(self.useQueue())


	@commands.command()
	async def songs(self):
		'Prints the songs in the queue'
		ret = ""
		if len(self.queue) != 0: #There is something in the Queue
			count = 1
			if len(self.queue) <= MAX_SONGS_SHOWN: #There are less than [MAX_SONGS_SHOWN] in the Queue
				await self.bot.say("**The Following songs are in the Queue**")
				for song in self.queue:
					ret += str(count) + ". " + song.title +"\n\t<" + song.url + ">\n"
					count+=1
			else:
				await self.bot.say("**The Following songs are in the Queue, plus [{}] more**".format(len(self.queue) - MAX_SONGS_SHOWN))
				for x in range(0,MAX_SONGS_SHOWN,1):
					ret += str(count) + ". " + self.queue[x].title +"\n\t<" + self.queue[x].url + ">\n"
					count+=1
		else:
			await self.bot.say("Queue is Empty")
			return
		ret += "Total Time is {}".format(str(datetime.timedelta(seconds = self.totalTime(self.queue))))
		await self.bot.say(ret)


	def totalTime(self, queue):
		time = 0
		for elem in queue:
			time += elem.duration
		return time

	@commands.command()
	async def shuffle(self):
		'Shuffles the songs in the Queue'
		await self.bot.say("Shuffling songs...")
		random.shuffle(self.queue)

	@commands.command(hidden = True)
	async def remove(self,number : int):
		'removes a song from a queue by index'
		await self.bot.say("Removed: " + self.queue.pop(number - 1).title)

	@commands.command()
	async def playlist(self, *names : str):
		'Adds songs from a predefined playlist to the songs list'
		with open('Playlists.json', 'r') as f:
			self.playlist = json.load(f)
		for name in names:
			random.shuffle(self.playList[name])
			for song in self.playList[name]:
				try:
					current = await self.voice.create_ytdl_player(song)
					self.queue.append(current);
					print("Added Song to Queue")
				except Exception as e:
					print("Could Not Add a Song... Skipping it: <{}>".format(e))

		await self.bot.say("Finished Adding songs from playlist(s)")

	@commands.command()
	async def makeplaylist(self, name, *links : str):
		'Makes a custom playlist for the bot to save'
		with open('Playlists.json', 'r') as f:
			self.playList = json.load(f)
		if(name in self.playList.keys()):
			await self.bot.say("Playlist already exists")
			return
		self.playList[name] = list(links)
		with open('Playlists.json', 'w') as f:
			json.dump(self.playList, f)
		await self.bot.say("Created Playlist {} with {} songs".format(name, len(list(links))))

	@commands.command()
	async def viewplaylist(self, name):
		'Views the songs of a playlists'
		with open('Playlists.json', 'r') as f:
			self.playList = json.load(f)
		if(name not in self.playList.keys()):
			await self.bot.say("Playlist does not exists")
			return
		songNames = await self.getNames(self.playList[name])
		await self.bot.say("\n".join(songNames))

	async def getNames(self, names):
		cleanNames = []
		for name in names:
			try:
				song = await self.voice.create_ytdl_player(name)
			except Exception as e:
				await self.bot.say("Please have me join a channel before you access my playlists")
				return
			cleanNames.append(song.title + " <{}>".format(song.url))
		return cleanNames


	@commands.command()
	async def extendplaylist(self, name, *links : str):
		'Extends a custom playlist'
		with open('Playlists.json', 'r') as f:
			self.playList = json.load(f)
		if(name not in self.playList.keys()):
			await self.bot.say("Playlist does not exists")
			return
		self.playList[name].extend(list(links))
		with open('Playlists.json', 'w') as f:
			json.dump(self.playList, f)

	@commands.command(hidden = True)
	async def removeplaylist(self, name):
		'Removes a custom playlist'
		with open('Playlists.json', 'r') as f:
			self.playList = json.load(f)
		if(name not in self.playList.keys()):
			await self.bot.say("Playlist does not exists")
			return			
		del self.playList[name]
		with open('Playlists.json', 'w') as f:
			json.dump(self.playList, f)
		await self.bot.say("Removed {}".format(name))


	@commands.command(hidden = True)
	async def forceplay(self, link : str):
		current = await self.voice.create_ytdl_player(link)
		if(self.player != None):
			self.player.stop()
		self.player = current
		current.start()

	@commands.command()
	async def loop(self, num = 1):
		current = await self.voice.create_ytdl_player(self.player.url)
		for x in range(0,num,1):
			self.queue.insert(0, current)
		await self.bot.say("Added '*{}*' **{}** more times".format(self.player.title, num))

	@commands.command()
	async def playlists(self):
		with open('Playlists.json', 'r') as f:
			self.playList = json.load(f)
		Names = []
		for name, songs in self.playList.items():
			if(songs != None and name != None):
				Names.append(name + "[" + str(len(songs)) + "]")
		await self.bot.say(", ".join(Names))

	@commands.command(pass_context = True)
	async def youtube(self,ctx, * links : str):
		'Adds a Song for the Bot to Play'
		if(self.voice == None):
			await self.bot.say("I am not connected to a Voice Chat!")

		for link in links:
			if("www.youtube.com/watch?v" not in link and "https://youtu.be/" not in link):
				await self.bot.say("Not a Valid Link, Please only use URLs from youtube.com")
				break
			current = await self.voice.create_ytdl_player(link)
			if(current.views < MIN_VIEWS):
				await self.bot.say("Sorry, that video has too little views to be Trustworthy. Needs [{}] but has [{}]".format(format(MIN_VIEWS, ",d"), format(current.views, ",d")))
				break
			if(current.dislikes / (current.dislikes + current.likes) > MAX_PERCENT_DISLIKE):
				await self.bot.say("Sorry, too many people dislike that video. Needs to be above [{}%] but was [{}%]".format(MAX_PERCENT_DISLIKE * 100, round(current.dislikes / (current.dislikes + current.likes) * 100,2)))
				break
			await self.bot.say("Added {} to the queue".format(current.title))
			self.queue.append(current)
			print("Added Song to Queue")
			#await asyncio.sleep(3)

		# self.player.start()
		#print(player.views, player.likes, player.dislikes)
	@commands.command(pass_context = True)
	async def search(self, ctx, * Pinput : str):
		count = 0
		link = youtube("+".join(Pinput), count)
		current = await self.voice.create_ytdl_player(link)
		while(current == None or current.views < MIN_VIEWS or current.dislikes / (current.dislikes + current.likes) > MAX_PERCENT_DISLIKE):
			link = youtube("+".join(Pinput), count)
			current = await self.voice.create_ytdl_player(link)
			count += 1
		await self.bot.say("Added {} to the queue".format(current.title))
		await self.bot.say(link)
		self.queue.append(current)

	async def useQueue(self):
		await self.bot.wait_until_ready()
		print("Running Queue")
		while not self.bot.is_closed:
			if len(self.queue) != 0:
				if self.player is None:
					print("Starting to play music")
					song = self.queue.pop(0)
					await self.playSong(song)
				if self.player.is_playing() is False:
					print("Playing next song...")
					song = self.queue.pop(0)
					await self.playSong(song)
			await asyncio.sleep(1)
		print("Finished Queue :(")


	async def playSong(self, current):
		if(self.player != None):
			self.player.stop()
		link = current.url
		current = await self.voice.create_ytdl_player(link)
		self.player = current
		current.start()


	@commands.command(pass_context = True)
	async def join(self,ctx):
		'Joins the Voice channel you are currently in'
		#self.voice == self.bot.voice_client_in(ctx.message.server)
		if self.voice != None:
			await self.bot.say("Sorry, I'm already connected to a channel in server {}".format(self.voice.server))
			return
		channel = ctx.message.author.voice_channel
		if channel is None:
			await self.bot.say("You are not connected to a voice channel!")
		else:
			self.voice = await self.bot.join_voice_channel(channel)

	@commands.command()
	async def leave(self):
		'Leaves the Join chat'
		await self.voice.disconnect()
		self.voice = None

	@commands.command()
	async def song(self):
		'Returns information about the current playing song'
		try:
			await self.bot.say("```" + 
			"Name: " + str(self.player.title) + "\n" + 
			"URL: <" + str(self.player.url) + ">\n" + 
			"Time: " + str(datetime.timedelta(seconds = self.player.duration)) + "\n" +
			"Views: " + str(format(self.player.views, ',d')) + "\n" +
			"Likes: " + str(format(self.player.likes, ',d')) + ", " + str(round(self.player.likes/(self.player.likes + self.player.dislikes) * 100, 2)) + "%\n" + 
			"Dislikes: " + str(format(self.player.dislikes, ',d')) + ", " + str(round(self.player.dislikes/(self.player.likes + self.player.dislikes) * 100, 2)) + "%\n" +  
			"```")
		except Exception as e:
			await self.bot.say("No Song Playing, [{}]".format(e))

	@commands.command()
	async def desc(self):
		'Decription of the Current playing song'
		await self.bot.say("Current Song Description:\n{}".format(self.player.description[:1000]))

	@commands.command()
	async def skip(self):
		'Skips the Current song'
		await self.bot.say("Skipping {}".format(self.player.title))
		self.player.stop()


def setup(bot):
	bot.add_cog(MusicPlayer(bot))

	
